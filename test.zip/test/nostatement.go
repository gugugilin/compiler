//test nostatement
a["test"]=5 //4
switch "test" //2
a[3+8]="true"+5 //2
a[true]=3 //4
/*
 * return var a int = 5 is legitimate with the programe of calss's pdf
 * return a=5 is not legitimate with the programe of class's pdf
 */
//must be 12 error
