//test statement with int_exp
var a[100] int
a[3+8]=5.5E+10
println a[11]
a[3]=10
println a[3]
var b int = 3
var c bool = true
var d bool = false
d=c
//a[3]=c&true
b=a[3]
println b
println a[3]
a[3]=a[3+8]
a[(((3+8)-2*2)/3)^2]=-(((8.6+3)-2*2)/3)^2
println -(((3+8.6)-2*2)/3)^2
println 5
println -(((3+8.6)-2*2)/3)^2
return -(((3+8.6)-2*2)/3)^2
return a[3+8]
//test statement with bool_exp
//a = true
var x[100] bool
x[3+8]=true
x[3]=true
x[(((3+8)-2*2)/3)^2]=!(true&true)&(true|true)
println true
println !(true&true)&(true|true)
println false
println !(true&false)&(true|false)
return !(true&true)&(true|true)
//test statement with constant
var z string
z="test"
read a
a[0] = a[0] + a[0]
return 


//var a  = 5
