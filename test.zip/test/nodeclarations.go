//test nodeclarations
//a = 5 this is the statement
var a int = 5 = 3
var a int = b = 3
var a = 5
var a string = "test1"+"test2"
var a int = true+5
var a int = "test"+5
var a["test"] string = 5+3
var a[100] int = a[3+8]
var a int = b
var a = b
// must be 26 error


