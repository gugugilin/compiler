// Hello World Example
/*

I am cat
cat am I

*/
var a bool = true&false
print 4-5
var a int = 5
print 4-5
a=-5
func main ( ) {
	a = 5;
	b = 5.0e-10;
	b = 5.0e+10;
	b = 5.0E-1;
	b = 5.0E+10;
	c = 5.0;
	d = """;
	d = "''"""""""""""""""""""""""""""""""""""""""""""""""""""""""""""x";
    println "Hello World";
}
