//test declarations
var a0 real = 5+5.5
var a111 int =3-5
var a1[100]int
var a2 int = 5
var a3 int = -5
var a4 real = 5.5+5
var a5 real = 5.5+5.5
var a6 real = 5.5E+15
var a7 real = -5.5E+5
var a8 real = +5.5E+5
var a9 real = 5.5E-2
var a10 real = -5.5E-2
var a11 real = +5.5E-2
var a12 int =5+3
var a14 real =+5.5E-2 - -5.5E-2
var a15 bool = true
var a16 bool = false&true
const a40 = 5.5
var a17 bool = a40>2 
var a18 string = "test"
var a19 int
var a20 real
var a21 bool
var a22 bool
var a23 string
const a24  = 5000000
const a25  = -a24
const a26  = 5.5E+5
const a27  = -5.5E+10
const a28  = +1.0E+6
const a29  = 5.5E-2
const a30  = -5.5E-2
const a31  = +5.5E-2
const a32  =5+3
const a33  =5+3
const a34  =+5.5E-2 - -5.5E-2
const a35  = false&true
const a36  = true
const a37  = !false
const a38  = "test"

